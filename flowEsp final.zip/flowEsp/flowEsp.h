
#ifndef FLOW_ESP_H
#define FLOW_ESP_H

void mqttCallback(char* topic, byte* message, unsigned int len);

void mqttConnect();

void mqttInit();

void initializeDataSender();

void sendData(float cons, float vol);


#endif